This is a set of 3dsmax5 files which will help you create and export
custom made character skins and skeleton animations for Max Payne 2.

Required software:
- Max Payne 2 PC game
- Max Payne 2 Tools
- 3dsmax5.1 (SP1) with Character Studio 4.1

Installation:
- Copy the "MaxScript" utilities from the "Max Payne2 Tools"
  installation package over to your 3dsmax installation folder.
- Make sure the MaxScript tools actually work. Eg, create a new
  toolbar such as RemedyTools, and drag over the "Remedy FigureMode
  on/off" and the "Export Biped" buttons over to it, and make
  sure they run if you have a biped in the scene.

Copyright Take-Two Interactive Software, Inc.