
	Particle bitmap add-on pack


	 This pack contains some more of the particle bitmaps sequences used 
	in Max Payne. You can add them to the existing examples by simply
	extracting this .ZIP to the Examples directory under the ParticleFX
	directory.

	The sequences are divided into categories as separate .txt files:

Debris.txt contains:

	- Paper_Confetti - fluttering pieces of paper
	- Wood_Splinters - bits of wood
	- Glass_Shards - shards of glass
	- Shreds - irregularly shaped pieces of debris

	 All these bitmap sequences are white as default, and must be colored
	by using the particle's Color Graph. This allows you to save texture
	memory by using the same bitmaps for several different purposes.


Liquid.txt contains:

	- Liquid - a random liquid droplet splat (3 randomized sequences)
	- Droplet - a single transparent round droplet

	 As above, these sequences can be colored with the Color Graph
	to make blood, etc.

Explosions.txt contains:

	- Explosion - a basic explosion
	- Fire_Explosion - an uprising gasoline fireball

	 These bitmaps are additive and unlike the alpha blended ones,
	they are colored. If you colorize these with the Color Graph,
	the color of the graph will be multiplied on the bitmap.




	(C) Remedy Entertainment 2001
