Installing Your MySpace Theme

1. Open the .txt file
2. Copy all the text
3. Goto Edit Your Profile on MySpace.com
4. Paste the text into the bottom of your About Me section.
5. Save the changes and you're done!