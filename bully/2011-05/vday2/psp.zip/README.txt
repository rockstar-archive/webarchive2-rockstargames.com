To play this video on your PSP, download the file to your desktop, then transfer to your PSP via USB connection, to the following folder:  /MP_ROOT/100ANV01

