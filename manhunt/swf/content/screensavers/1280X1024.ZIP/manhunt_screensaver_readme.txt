MANHUNT SCREENSAVER README

Installation Instructions:

1.  Download the appropriate zip file for your screen resolution and extract the contents.

2.  Locate the extracted setup file and double-click it.  Press the "install" button in the pop-up dialogue box.

3.  Verify that the screensaver is set up and working properly by right-clicking on your desktop, selecting "properties" from the pop-up menu, then the "Screen Saver" tab in the dialogue box.

Notes:

*  This is an internet-enabled screensaver that will automatically update itself.  Your experience may change depending on whether or not you are connected to the internet.

*  Firewall users:  For full functionality of this screensaver, either open port 80 or enable internet access for "Screentime Screensaver Engine".  You can choose not to do this, but your screensaver will not dynamically update.
